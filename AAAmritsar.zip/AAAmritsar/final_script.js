/ Menu toggle functionality
f/unction toggleMenu() {
    const sidebar = document.getElementById('sideMenu');
    const overlay = document.getElementById('overlay');
    const body = document.body;
    
    // Toggle sidebar
    sidebar.classList.toggle('open');
    overlay.classList.toggle('active');
    
    // Prevent body scroll when menu is open
    if (sidebar.classList.contains('open')) {
        body.style.overflow = 'hidden';
    } else {
        body.style.overflow = 'auto';
    }
}

// Smooth scrolling for navigation links
document.addEventListener('DOMContentLoaded', function() {
    // Add smooth scrolling behavior to all navigation links
    const navLinks = document.querySelectorAll('.nav-link[href^="#"]');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                // Calculate offset for fixed header
                const headerOffset = 100;
                const elementPosition = targetSection.getBoundingClientRect().top;
                const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
                
                window.scrollTo({
                    top: offsetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', function(e) {
        const sidebar = document.getElementById('sideMenu');
        const menuToggle = document.querySelector('.menu-toggle');
        const overlay = document.getElementById('overlay');
        
        // If click is outside sidebar and not on menu toggle
        if (!sidebar.contains(e.target) && !menuToggle.contains(e.target) && sidebar.classList.contains('open')) {
            toggleMenu();
        }
    });
    
    // Handle escape key to close menu
    document.addEventListener('keydown', function(e) {
        const sidebar = document.getElementById('sideMenu');
        
        if (e.key === 'Escape' && sidebar.classList.contains('open')) {
            toggleMenu();
        }
    });
    
    // Add active state to navigation links based on scroll position
    const sections = document.querySelectorAll('.content-section');
    const navLinksArray = Array.from(navLinks);
    
    function updateActiveNavLink() {
        const scrollPos = window.pageYOffset + 150;
        
        sections.forEach(section => {
            const sectionTop = section.getBoundingClientRect().top + window.pageYOffset;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');
            
            if (scrollPos >= sectionTop && scrollPos < sectionTop + sectionHeight) {
                // Remove active class from all links
                navLinksArray.forEach(link => link.classList.remove('active'));
                
                // Add active class to current link
                const activeLink = navLinksArray.find(link => link.getAttribute('href') === `#${sectionId}`);
                if (activeLink) {
                    activeLink.classList.add('active');
                }
            }
        });
    }
    
    // Add scroll event listener with throttling
    let ticking = false;
    
    function handleScroll() {
        if (!ticking) {
            requestAnimationFrame(() => {
                updateActiveNavLink();
                ticking = false;
            });
            ticking = true;
        }
    }
    
    window.addEventListener('scroll', handleScroll);
    
    // Add hover effects and touch support for mobile
    const interactiveElements = document.querySelectorAll('.content-section, .contact-link, .map-btn, .help-btn');
    
    interactiveElements.forEach(element => {
        // Add touch start/end events for mobile hover effects
        element.addEventListener('touchstart', function() {
            this.classList.add('touch-active');
        });
        
        element.addEventListener('touchend', function() {
            setTimeout(() => {
                this.classList.remove('touch-active');
            }, 150);
        });
    });
    
    // Animate sections on scroll (intersection observer)
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const sectionObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);
    
    // Observe all content sections
    sections.forEach(section => {
        sectionObserver.observe(section);
    });
    
    // Handle phone number clicks with confirmation on desktop
    const phoneLinks = document.querySelectorAll('a[href^="tel:"]');
    
    phoneLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // On desktop, show confirmation dialog
            if (window.innerWidth > 768) {
                const phoneNumber = this.getAttribute('href').replace('tel:', '');
                const confirmed = confirm(`Would you like to call ${phoneNumber}?`);
                
                if (!confirmed) {
                    e.preventDefault();
                }
            }
        });
    });
    
    // Add loading animation completion
    setTimeout(() => {
        document.body.classList.add('loaded');
    }, 100);
    
    // Handle resize events
    let resizeTimer;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
            // Close menu if window is resized to desktop
            if (window.innerWidth > 768) {
                const sidebar = document.getElementById('sideMenu');
                const overlay = document.getElementById('overlay');
                
                if (sidebar.classList.contains('open')) {
                    sidebar.classList.remove('open');
                    overlay.classList.remove('active');
                    document.body.style.overflow = 'auto';
                }
            }
        }, 250);
    });
});

// Add CSS for active nav links and animations
const additionalStyles = `
    .nav-link.active {
        background: #e5e7eb;
        color: #1e3a8a;
        border-left-color: #3b82f6;
        transform: translateX(4px);
    }
    
    .nav-link.active i {
        color: #3b82f6;
    }
    
    .touch-active {
        transform: scale(0.98);
    }
    
    .animate-in {
        animation: slideInUp 0.6s ease-out;
    }
    
    @keyframes slideInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    body.loaded .content-section {
        opacity: 1;
        transform: translateY(0);
    }
`;

// Inject additional styles
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);

// Utility function to format phone numbers for display
function formatPhoneNumber(phoneNumber) {
    // Remove all non-digit characters
    const cleaned = phoneNumber.replace(/\D/g, '');
    
    // Format as Indian mobile number
    if (cleaned.length === 10) {
        return cleaned.replace(/(\d{5})(\d{5})/, '$1 $2');
    }
    
    return phoneNumber;
}

// Apply phone number formatting on load
document.addEventListener('DOMContentLoaded', function() {
    const phoneSpans = document.querySelectorAll('.contact-link .phone-number, .contact-link span:not(.contact-person)');
    phoneSpans.forEach(span => {
        const formatted = formatPhoneNumber(span.textContent);
        span.textContent = formatted;
    });
});

// Add service worker for offline functionality (optional enhancement)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        // Only register if we have a service worker file
        // This is commented out as we're not creating the service worker file
        // navigator.serviceWorker.register('/sw.js');
    });
}

// Performance optimization: preload critical resources
function preloadCriticalResources() {
    // Preload Google Fonts
    const fontLink = document.createElement('link');
    fontLink.rel = 'preload';
    fontLink.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap';
    fontLink.as = 'style';
    fontLink.onload = function() {
        this.onload = null;
        this.rel = 'stylesheet';
    };
    document.head.appendChild(fontLink);
    
    // Preload Font Awesome
    const iconLink = document.createElement('link');
    iconLink.rel = 'preload';
    iconLink.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css';
    iconLink.as = 'style';
    iconLink.onload = function() {
        this.onload = null;
        this.rel = 'stylesheet';
    };
    document.head.appendChild(iconLink);
}

// Call preload function
preloadCriticalResources();