# Golden Group AA Website

## Overview

This is a website for the Golden Group of Alcoholics Anonymous in Amritsar. It's a simple, single-page application built with vanilla HTML, CSS, and JavaScript that provides information about the AA group, including their purpose, meeting details, and contact information. The site features a responsive design with a mobile-friendly sidebar navigation system.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Single Page Application (SPA)**: Built with vanilla HTML, CSS, and JavaScript without any frameworks
- **Responsive Design**: Mobile-first approach with a collapsible sidebar navigation for smaller screens
- **Component Structure**: Modular sections including welcome, purpose, meeting details, contact, and help sections
- **Navigation System**: Fixed top navigation bar with hamburger menu that reveals a slide-out sidebar

### Styling Architecture
- **CSS Framework**: Custom CSS with modern features like CSS Grid and Flexbox
- **Design System**: Uses Inter font family and a blue/gold color scheme appropriate for the organization
- **Responsive Breakpoints**: Mobile-first design with sidebar navigation for smaller screens
- **Animation**: Smooth scrolling and CSS transitions for interactive elements

### JavaScript Architecture
- **Vanilla JavaScript**: No external JavaScript frameworks or libraries
- **Event-Driven**: Uses DOM event listeners for menu interactions and smooth scrolling
- **Modular Functions**: Separate functions for menu toggling and smooth scrolling behavior
- **Accessibility**: Includes ARIA labels and keyboard navigation support

### File Structure
- `index.html` - Main HTML structure and content
- `styles.css` - All styling and responsive design rules
- `script.js` - Interactive functionality for navigation and user interactions

## External Dependencies

### CDN Resources
- **Google Fonts**: Inter font family for modern typography
- **Font Awesome**: Icon library (version 6.4.0) for navigation and visual elements

### Browser APIs
- **DOM API**: For element manipulation and event handling
- **Scroll API**: For smooth scrolling functionality and scroll position management
- **CSS Grid/Flexbox**: For responsive layout management

No backend services, databases, or authentication systems are currently implemented. The site is entirely client-side and can be deployed as static files.